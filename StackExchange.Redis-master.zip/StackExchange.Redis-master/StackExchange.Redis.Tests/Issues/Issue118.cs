﻿namespace StackExchange.Redis.Tests.Issues
{
    class Issue118
    {
    }
}
