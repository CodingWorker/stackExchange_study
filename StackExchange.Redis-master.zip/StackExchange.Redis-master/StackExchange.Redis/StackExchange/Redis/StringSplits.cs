﻿namespace StackExchange.Redis
{
    class StringSplits
    {
        public static readonly char[]
            Space = { ' ' },
            Comma = { ',' };

    }
}
