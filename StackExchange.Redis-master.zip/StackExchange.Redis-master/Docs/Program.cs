﻿[assembly: System.Reflection.AssemblyVersion("1.0.0")]
static class Program
{
    static void Main() { System.Console.WriteLine("This is a place-holder project just to make file management easier"); }
}
