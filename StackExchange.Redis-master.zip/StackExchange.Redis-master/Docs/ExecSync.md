﻿The Dangers of Synchronous Continuations
===

Once, there was more content here; then [a suitably evil workaround was found](http://stackoverflow.com/a/22588431/23354). This page is not
listed in the index, but remains for your curiosity.